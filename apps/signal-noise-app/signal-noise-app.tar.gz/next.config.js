/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  port: 7668,
  hostname: '0.0.0.0',
  experimental: {
    // Disable static generation to avoid build-time API calls
    isrMemoryCacheSize: 0,
  },
  // Skip API routes that cause build issues
  async rewrites() {
    return [
      // Skip problematic API routes during build
      {
        source: '/api/production-pipeline-analytics/:path*',
        destination: '/api/placeholder',
      },
      {
        source: '/api/rfp-backtesting/:path*',
        destination: '/api/placeholder',
      },
      {
        source: '/api/supabase-query/:path*',
        destination: '/api/placeholder',
      }
    ]
  }
}

module.exports = nextConfig
