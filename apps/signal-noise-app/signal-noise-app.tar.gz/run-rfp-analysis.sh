#!/bin/bash

# RFP Analysis Script - Direct API Call
# This script runs the comprehensive RFP analysis without frontend

echo "🚀 Starting RFP Analysis..."
echo "Processing 3 sports entities with BrightData searches"
echo "This will take 2-3 minutes for comprehensive analysis"
echo ""

# Run the analysis using curl with SSE streaming
curl -N "http://localhost:3005/api/claude-agent-demo/stream?service=reliable&query=Comprehensive%20RFP%20intelligence%20analysis&mode=batch&entityLimit=3&startEntityId=0" \
  -H "Accept: text/event-stream" \
  -H "Cache-Control: no-cache" \
  -H "Connection: keep-alive"

echo ""
echo "✅ Analysis completed!"